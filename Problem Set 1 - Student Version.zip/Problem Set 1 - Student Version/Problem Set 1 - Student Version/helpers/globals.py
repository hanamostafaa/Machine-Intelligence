from helpers import test_tools
from graph import GraphRoutingProblem
from sokoban import SokobanProblem
from sokoban_heuristic import weak_heuristic